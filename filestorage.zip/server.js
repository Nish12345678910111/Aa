const express = require("express");
const multer = require("multer");
const bcrypt = require("bcrypt");
const session = require("express-session");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));
app.use(session({
  secret: "secret-key",
  resave: false,
  saveUninitialized: true
}));

const users = {};  // for demo; in real use DB

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (!req.session.user) return cb(new Error("Not logged in"));
    const userDir = path.join(__dirname, "uploads", req.session.user);
    fs.mkdirSync(userDir, { recursive: true });
    cb(null, userDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});
const upload = multer({ storage });

function auth(req, res, next) {
  if (req.session.user) next();
  else res.status(401).send("Not logged in");
}

// Signup
app.post("/signup", async (req, res) => {
  const { username, password } = req.body;
  if (users[username]) return res.status(400).send("User exists");
  const hash = await bcrypt.hash(password, 10);
  users[username] = { password: hash };
  res.send("Account created");
});

// Login
app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!users[username]) return res.status(400).send("No user");
  const ok = await bcrypt.compare(password, users[username].password);
  if (!ok) return res.status(400).send("Wrong password");
  req.session.user = username;
  res.send("Logged in");
});

// Logout
app.post("/logout", (req, res) => {
  req.session.destroy(() => res.send("Logged out"));
});

// Upload
app.post("/upload", auth, upload.single("file"), (req, res) => {
  res.send("File uploaded");
});

// List files
app.get("/files", auth, (req, res) => {
  const userDir = path.join(__dirname, "uploads", req.session.user);
  if (!fs.existsSync(userDir)) return res.json([]);
  const files = fs.readdirSync(userDir);
  res.json(files);
});

// Download
app.get("/download/:filename", auth, (req, res) => {
  const filePath = path.join(__dirname, "uploads", req.session.user, req.params.filename);
  if (!fs.existsSync(filePath)) return res.status(404).send("File not found");
  res.download(filePath);
});

// Delete
app.delete("/delete/:filename", auth, (req, res) => {
  const filePath = path.join(__dirname, "uploads", req.session.user, req.params.filename);
  if (!fs.existsSync(filePath)) return res.status(404).send("File not found");
  fs.unlinkSync(filePath);
  res.send("File deleted");
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
